<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial- scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Halaman <?= $data['judul']; ?></title>
        
        
    </head>
    <body>
        
    <div class="card text-center">
                            <div class="card-body">
        <div class="container mt-6">
        <div class="col-sm-12">
            <div class="card-body">
                <h5 class="card-title">KOMPETENSI KEAHLIAN SMK NEGERI 2 TRENGGALEK</h5>
                <div class="row no-gutters">
                    <div class="col-md-4">
                    <img src="img/akl.jpg" class="img-fluid" alt="" width="1100px" >
</div>

                          <div class="col-md-5">
                            <div class="card-body">
                                <h5 class="card-title">AKL</h5>
                                
                                <p class="card-text">Akuntansi merupakan sebuah Kompetensi Keahlian (Jurusan) yang sangat berhubungan dengan angka dan hitung menghitung.
                                    Hampir setiap hari kalian akan dihadapkan dengan pelajaran hitung menghitung.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                            <div class="card-body">
                            <div class="row no-gutters">
                            <div class="col-md-4">
                                <img src="img/rpl.jpg" class="img-fluid" alt="" width="1100px">
</div>
                                <div class="col-md-5">
                                <div class="card-body">
                                <h5 class="card-title">RPL</h5>

                                <p class="card-text">RPL merupakan sebuah jurusan yang mempelajari dan mendalami semua cara-cara pengembangan perangkat lunak termasuk pembuatan, pemeliharaan, manajemen organisasi pengembangan perangkat lunak dan manajemen kualitas.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                            <div class="card-body">
                            <div class="row no-gutters">
                            <div class="col-md-4">
                                <img src="img/tb.jpg" class="img-fluid" alt="" width="1100px">
</div>
                                <div class="col-md-5">
                                <div class="card-body">
                                <h5 class="card-title">TB</h5>
                                <p class="card-text">Tata Boga merupakan ilmu tentang bagaimana teknik untuk menyajikan makanan dengan memperhatikan beberapa faktor yaitu estetika atau keindahan, kualitas rasa masakan, serta nilai kebutuhan gizinya.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                            <div class="card-body">
                           <div class="row no-gutters"> 
                            <div class="col-md-4">
                                <img src="img/dpib.jpg" class="img-fluid" alt="" width="1100px">
</div>
                                <div class="col-md-5">
                                <div class="card-body">
                                <h5 class="card-title">DPIB</h5>
                                <p class="card-text">Desain Pemodelan dan Informasi Bangunan merupakan jurusan yang mempelajari tentang perencanaan bangunan, pelaksanaan pembuatan gedung dan perbaikan gedung.
                                    Kegiatannya adalah belajar menggambar rumah, gedung dan apartemen, menghitung biaya bangunan, melaksankan pembangunan dan memelihara kontruksi bangunan.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                            <div class="card-body">
                            <div class="row no-gutters"> 
                            <div class="col-md-4">
                                <img src="img/kgsp.jpeg" class="img-fluid" alt="" width="1100px">
</div>
                                <div class="col-md-5">
                                <div class="card-body">
                                <h5 class="card-title">KGSP</h5>
                                <p class="card-text">Kontruksi Gedung Sanitasi dan Perawatan (KGSP) merupakan sebuah Paket Keahlian baru, para peserta didik akan belajar tentang membangun sebuah bangunan, sanitasi dan kegiatan untuk merawatnya.
                                    Program belajar KGSP ini, diikuti oleh peserta didik selama 4 tahun.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                            <div class="card-body">
                            <div class="row no-gutters"> 
                            <div class="col-md-4">
                                <img src="img/tptu.jpg" class="img-fluid" alt="" width="1100px">
</div>
                                <div class="col-md-5">
                                <div class="card-body">
                                <h5 class="card-title">TPTU</h5>
                                <p class="card-text">Teknik Pendinginan dan Tata Udara (TPTU) merupakan salah satu Kompetensi Keahlian dari Program Keahlian: Teknik Ketenagalistrikan dan Bidang Keahlian: Teknologi dan Rekayasa.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>