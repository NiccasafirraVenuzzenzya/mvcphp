<div class="container text-center mt-4">
    <h1>Halaman User</h1>
    <img src="/img/Profile.png" class="rounded-circle shadow">
    <p>Halo, nama saya <?= $data['nama']; ?>, saya seorang <?= $data['pekerjaan']; ?></p>
</div>